package tp7_8_v2;

public class AttaqueBulle extends AttaqueSpeciale {
	public AttaqueBulle() {
		super("bulle", new String[] {"EAU"}, 40, 100, 30);
	}
}
