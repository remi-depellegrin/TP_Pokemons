package tp7_8_v2;

public class AttaqueCoupDeTete extends AttaquePhysique {
	public AttaqueCoupDeTete() {
		super("coup de tete", 70, 100, 15);
	}
}
