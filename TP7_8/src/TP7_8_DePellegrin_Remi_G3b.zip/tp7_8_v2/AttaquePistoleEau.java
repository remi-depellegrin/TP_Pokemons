package tp7_8_v2;

public class AttaquePistoleEau extends AttaqueSpeciale {
	public AttaquePistoleEau() {
		super("pistole d'eau", new String[] {"EAU"}, 40, 100, 25);
	}
}
