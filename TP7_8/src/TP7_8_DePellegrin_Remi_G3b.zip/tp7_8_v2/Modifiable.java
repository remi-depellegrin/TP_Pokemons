package tp7_8_v2;

public interface Modifiable {
	public void modifier();
}
