package tp7_8_v2;

public class AttaqueTornadeFeuilles extends AttaqueSpeciale {
	public AttaqueTornadeFeuilles() {
		super("tornade feuilles", new String[] {"PLANTE"}, 65, 90, 10);
	}
}
