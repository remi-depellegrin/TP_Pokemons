package tp7_8_v2;

public interface ChangerItems {
	public void changer(Modifiable item);
}
