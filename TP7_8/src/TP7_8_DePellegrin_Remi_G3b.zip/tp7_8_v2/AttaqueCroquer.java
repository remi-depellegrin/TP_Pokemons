package tp7_8_v2;

public class AttaqueCroquer extends AttaquePhysique {
	public AttaqueCroquer() {
		super("croquer", 80, 100, 15);
	}
}
