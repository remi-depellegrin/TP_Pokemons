package tp7_8_v2;

public class AttaqueEnfer extends AttaqueSpeciale {
	public AttaqueEnfer() {
		super("enfer", new String[] {"FEU"}, 100, 50, 5);
	}
}
