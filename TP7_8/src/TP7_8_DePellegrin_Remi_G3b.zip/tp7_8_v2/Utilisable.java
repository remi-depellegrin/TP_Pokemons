package tp7_8_v2;

public interface Utilisable {
	public void utiliser(Joueur joueur, int indexPokemon);
}
