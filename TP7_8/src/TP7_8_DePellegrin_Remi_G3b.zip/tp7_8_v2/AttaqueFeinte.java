package tp7_8_v2;

public class AttaqueFeinte extends AttaquePhysique {
	public AttaqueFeinte() {
		super("feinte", 30, 100, 10);
	}
}
