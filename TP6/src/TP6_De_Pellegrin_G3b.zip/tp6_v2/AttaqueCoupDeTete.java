package tp6_v2;

public class AttaqueCoupDeTete extends AttaquePhysique {
	public AttaqueCoupDeTete() {
		super("coup de tete", 70, 100, 15);
	}
}
