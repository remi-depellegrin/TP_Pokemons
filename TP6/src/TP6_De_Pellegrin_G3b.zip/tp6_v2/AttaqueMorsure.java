package tp6_v2;

public class AttaqueMorsure extends AttaquePhysique {
	
	public AttaqueMorsure() {
		super("morsure", 60, 100, 25);
	}
}
