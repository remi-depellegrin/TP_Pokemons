package tp6_v2;

public class AttaqueTornadeFeuilles extends AttaqueSpeciale {
	public AttaqueTornadeFeuilles() {
		super("tornade feuilles", new String[] {"PLANTE"}, 65, 90, 10);
	}
}
