package tp6_v2;

public class AttaqueTackle extends AttaquePhysique {
	public AttaqueTackle() {
		super("tackle", 40, 100, 35);
	}
}
